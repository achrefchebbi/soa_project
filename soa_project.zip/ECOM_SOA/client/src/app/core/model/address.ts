export class Address {
  id: number;
  city: string;
  street: string;
}

import {Product} from './product';

export class OrderProduct {
  public product: Product;
  public quantity = 0;
}

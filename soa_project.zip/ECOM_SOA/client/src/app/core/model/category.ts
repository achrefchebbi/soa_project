import {Product} from './product';

export class Category {

  id: number = undefined;
  name: string;
  products: Product[];
}
